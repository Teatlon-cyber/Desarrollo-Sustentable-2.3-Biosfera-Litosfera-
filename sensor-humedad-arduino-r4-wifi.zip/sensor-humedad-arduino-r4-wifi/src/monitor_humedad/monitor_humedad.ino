// Monitor de humedad del suelo - Arduino UNO R4 WiFi
// Sensor de humedad de suelo resistivo en A0, LED de alerta en el pin 13.

const int PIN_SENSOR = A0;   // Señal analógica del sensor
const int LED_PIN    = 13;   // LED (integrado y externo) de alerta de riego

// Umbral: ajústalo según las lecturas que veas en el Monitor Serie
const int UMBRAL_HUMEDAD = 400;

void setup() {
  Serial.begin(9600);
  pinMode(LED_PIN, OUTPUT);
  Serial.println("=== Monitor de humedad del suelo ===");
}

void loop() {
  int lectura = analogRead(PIN_SENSOR);

  // A menor lectura, menor porcentaje de humedad
  int porcentaje = map(lectura, 0, 1023, 0, 100);
  porcentaje = constrain(porcentaje, 0, 100);

  Serial.print("Lectura: ");
  Serial.print(lectura);
  Serial.print("  |  Humedad: ");
  Serial.print(porcentaje);
  Serial.print("%  |  Estado: ");

  // Lectura baja -> TIERRA SECA -> ENCIENDE el LED (alerta de riego)
  if (lectura < UMBRAL_HUMEDAD) {
    Serial.println("TIERRA SECA -> Se recomienda regar");
    digitalWrite(LED_PIN, HIGH);
  }
  // Lectura alta -> TIERRA HÚMEDA -> APAGA el LED
  else {
    Serial.println("TIERRA HUMEDA -> No necesita riego");
    digitalWrite(LED_PIN, LOW);
  }

  delay(1000);
}
